title: MySQL中MyISAM与Innodb引擎区别
date: '2018-09-06 04:21:37'
updated: '2019-01-28 10:26:47'
tags: [MySQL]
permalink: /articles/2018/09/05/1536132096331.html
---
整理一下MyISAM与Innodb引擎索引实现的区别


### 1. MyISAM的索引实现
1. MyISAM索引文件和数据文件是分离，索引文件仅保留记录所在页的指针。

![imagepng](http://xiajl.cn/upload/9091fd70a7634f18b81fbbdf97f0f280_image.png) 


### 2. Innodb的索引实现
1. Innodb的聚集索引，其叶子节点直接就是数据行。聚集索引可以避免读取数据文件时的随机IO。
![imagepng](http://xiajl.cn/upload/4240b1b3fd6b41c2af51a74703234618_image.png) 


2.Innodb的辅助索引，其叶子节点保存的是**主键**，因此在使用辅助索引时，必须要进行二次查询。
![imagepng](http://xiajl.cn/upload/7e284069addf4c9980848f840e421566_image.png) 


### 参考文献
https://blog.csdn.net/stfphp/article/details/52827845