title: Selenium自动化测试实践
date: '2019-06-01 10:14:43'
updated: '2019-06-01 10:19:42'
tags: [selenium]
permalink: /articles/2019/06/01/1559355283837.html
---
近期在公司做了一个分享，关于Selenium自动化测试实践的分享，这里贴一下。欢迎参观：
<iframe src="//player.bilibili.com/player.html?aid=52605939&cid=92057991&page=1" scrolling="no" border="0" style="width:760px;height:670px;" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>

视频主要讲解了Selenium的基本用法，它是如何与浏览器通信的，并且我们如何利用其中的通信协议来完成我们需要的，但Selenium并没有提供的功能。