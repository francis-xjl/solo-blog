title: Dubbo的ExtensionLoader小结
date: '2018-09-07 12:40:19'
updated: '2018-09-07 13:02:50'
tags: [dubbo, SPI]
permalink: /articles/2018/09/06/1536248418722.html
---
今天看了下dubbo的SPI实现，收益匪浅，这里总结一下：

### 1. 优点：相对于JDK原生的SPI机制
1.  按需加载，减少不必要的初始化
2.  扩展点加载失败，相比JDK，可以准确报出错误信息
3.  扩展点可以IOC以及AOP

### 2. 实现方案
那么dubbo是怎么做到以上三点的呢？

#### 1. 按需加载逻辑

以Transporter为例，在getAdaptiveExtension()时才会进行初始化动作，而并非在容器启动时加载所有的扩展类：

![imagepng](http://xiajl.cn/upload/e9c0b4ae3b894fd386f33251c3563c96_image.png) 

#### 2. 扩展点加载失败异常报告

在加载失败时会将具体扩展点信息打印出来，即便是循环依赖产生问题，也会准确报出错误信息。

![imagepng](http://xiajl.cn/upload/942fc5fb4f294f0b93bc91383e4f395f_image.png) 

#### 3. 扩展点可以IOC以及AOP

首先看下AOP的实现，dubbo在AOP上并没有通过字节码修改的方式，而是通过装饰器设计模式来实现的。ExtensionLoader 在加载扩展点时，如果加载到的扩展点有拷贝构造函数，则判定为扩展点 Wrapper类，而Wrapper类并不是真正的实现类，如下图所示：

![imagepng](http://xiajl.cn/upload/22e1cf3793cb454f8d7ce099a6defa76_image.png) 

Wrapper类可以有多个，并且会在所有的扩展点上添加逻辑。我们看下怎么实现的：

![imagepng](http://xiajl.cn/upload/41c020da0e8d4691838aedbcdc4fee76_image.png) 

在创建扩展点时，进行层层装饰，以实现AOP的逻辑，设计非常精妙。

我们再来看看IOC，dubbo的IOC，是通过set方法进行注入，如下图：

![imagepng](http://xiajl.cn/upload/cd25854466da4300895e6cc960a81980_image.png) 


如果有多个扩展类可以注入，dubbo会以如下优先级进行选择注入：
##### 1. 有@Adaptive注解的扩展实现类。

在扫描配置文件时，如果发现有Adaptive注解的类，则立即加入缓存，以该实现类优先返回。根据代码注意到，同一个扩展点，只能有一个默认实现。

![imagepng](http://xiajl.cn/upload/6b7e36c0652d4f7e97a38e9d4cc37970_image.png) 


扫描配置文件完毕后，如果已经发现找到Adaptive注解的类，则返回，代码如下：

![imagepng](http://xiajl.cn/upload/63be9ab53af646918b6590dc2f143499_image.png) 


##### 2. URL中定义的扩展点。

如果未发现有@Adaptive注解的类，dubbo会动态创建扩展点的实现类，以实现Adaptive注解的方法。这里注意到，SPI接口至少有一个方法需要@Adaptive注解，否则报错，如下图所示：

![imagepng](http://xiajl.cn/upload/98142e4106cb4d209168702bea5868ae_image.png) 


createAdaptiveExtensionClassCode是动态生成Java代码的部分，以下截图提取了最关键了部分。可以看看出，如果URL中存在定义的扩展点名称，则根据该名称获取对应的扩展实现类。

![imagepng](http://xiajl.cn/upload/3f41d745d702491c9b6324e10f845bab_image.png) 


##### 3. @SPI注解中的value定义的实现。
从上图可知，如果URL中没有定义，则采用SPI的默认扩展名来获取扩展实现类。


### 3. 参考文献
http://dubbo.apache.org/zh-cn/docs/dev/SPI.html

https://www.cnblogs.com/java-zhao/p/7617143.html

https://www.jianshu.com/p/dc616814ce98