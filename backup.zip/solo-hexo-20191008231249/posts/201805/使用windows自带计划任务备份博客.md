title: 使用windows自带计划任务备份博客
date: '2018-05-20 23:36:25'
updated: '2018-05-28 06:46:56'
tags: [任务计划]
permalink: /articles/2018/05/20/1526783784371.html
---
前两天使用crontab for windows的工具，实现了定时备份。在这几天的使用中发现，这个工具不太稳定，设置好了总是不太能正常运行，没能找到具体原因。由于crontab for windows也是基于windows的计划任务来运行，那我们可以尝试直接通过计划任务的方式来实现定期备份。

这次，我们不需要每天定时去备份数据，而是将备份数据的时机放在开机启动的时间。首先我们把上次的备份脚本进行重命名为download_backup.pyw，这是为了让脚本在执行的时候不会有窗口出来。

然后进入windows的任务计划任务，新建一个开机启动项，备份博客不需要特别高的优先级，所以将计划任务设置为启动后延迟一段时间执行，如下图所示：
![imagepng](http://xiajl.cn/upload/a9d053d92a144629a7c6a85aea21bab6_image.png) 

将我们的备份脚本加入到操作里：
![imagepng](http://xiajl.cn/upload/f34ce76deb944f1db1f93c715c010b8c_image.png) 

这样就完成了笔记本开机启动后，自动备份一次博客系统。


