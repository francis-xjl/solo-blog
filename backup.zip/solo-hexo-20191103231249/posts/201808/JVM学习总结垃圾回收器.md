title: JVM学习总结-垃圾回收器
date: '2018-08-07 10:28:15'
updated: '2019-01-28 10:28:40'
tags: [Java]
permalink: /articles/2018/08/06/1533562095087.html
---
JVM迄今为止(JDK10)，常见的垃圾回收器有7种，分别是：Serial 、Serial Old、ParNew、Parallel Scaverage 、 Parallel Old、 CMS、Garbage First(G1).我们来总结一下这七种垃圾器。

1\. Serial 与Serial Old

这两种都是串行垃圾回收器，即单线程模型。Serial回收年轻代，算法使用的是标记复制； Serial Old回收老年代，算法使用的是标记整理。

2.ParNew、Parallel Scaverage与Parallel Old

这三种垃圾回收器，都是并行垃圾回收器，即多线程模型。ParNew与Parallel Scaverage用来回收年轻代，算法使用的是标记复制； Parallel Old回收老年代，算法采用的是标记整理。

ParNew与Parallel Scaverage的区别在于，ParNew目标是减少垃圾回收时的用户暂停时间，用于响应速度要求较高的场景； 而Parallel Scaverage的目标是吞吐量最大化，尽可能降低总的暂停时间，适用于后台离线计算等不需要太多交互的场景，相对于ParNew可以减少总的暂停时间。

3.CMS

CMS的设计目标与Parallel New类似，尽可能降低垃圾回收时的用户暂停时间。CMS同时回收年轻代与老年代。CMS采用了标记清除算法，可以减少整理内存的时间，但是也带来了内存碎片的问题。

CMS垃圾回收的过程相对以上五种算法，整个过程比较复杂，如下图所示：
![imagepng](http://xiajl.cn/upload/ced7269151a94c80b60ea0f8c55191be_image.png) 


4.Garbage First(G1)

G1从jdk9开始成为默认垃圾回收器，G1的目标是并行并发、内存压缩、可预测性、高效、节约。G1将堆空间分为2048个区块，每个块的大小在1M~32M左右，每一个区块可以是新生代、存活区或是老年代。G1从整体上可以认为是标记整理算法，从单个区块上是标记复制算法。很明显，G1并不存在内存碎片的问题，空间是规整的。

![imagepng](http://xiajl.cn/upload/8a504c450fdb4dc29bf41fce57590214_image.png)




参考：

[http://www.importnew.com/27822.html](http://www.importnew.com/27822.html)

[https://blog.csdn.net/renfufei/article/details/41897113](https://blog.csdn.net/renfufei/article/details/41897113)